export const BOARD_WIDTH = 10;
export const BOARD_HEIGHT = 20;
export const NEXT_QUEUE_SIZE = 5;
export const LINES_PER_LEVEL = 10;
export const PIECE_TYPES = ["I", "J", "L", "O", "S", "T", "Z"];

export const PIECE_COLORS = {
  I: "#30dff3",
  J: "#4d7cff",
  L: "#ffae3d",
  O: "#ffe35b",
  S: "#58e06f",
  T: "#c879ff",
  Z: "#ff5a7a",
};

const PIECE_LIGHTS = {
  I: "#a9f7ff",
  J: "#b7c7ff",
  L: "#ffd49a",
  O: "#fff5a7",
  S: "#bdf7c8",
  T: "#e7c4ff",
  Z: "#ffb5c4",
};

const BASE_CELLS = {
  I: [
    [0, 1],
    [1, 1],
    [2, 1],
    [3, 1],
  ],
  J: [
    [0, 0],
    [0, 1],
    [1, 1],
    [2, 1],
  ],
  L: [
    [2, 0],
    [0, 1],
    [1, 1],
    [2, 1],
  ],
  O: [
    [1, 0],
    [2, 0],
    [1, 1],
    [2, 1],
  ],
  S: [
    [1, 0],
    [2, 0],
    [0, 1],
    [1, 1],
  ],
  T: [
    [1, 0],
    [0, 1],
    [1, 1],
    [2, 1],
  ],
  Z: [
    [0, 0],
    [1, 0],
    [1, 1],
    [2, 1],
  ],
};

const LINE_CLEAR_SCORES = [0, 100, 300, 500, 800];
const DEFAULT_KICKS = [
  [0, 0],
  [-1, 0],
  [1, 0],
  [-2, 0],
  [2, 0],
  [0, -1],
  [-1, -1],
  [1, -1],
];

function normalizeCells(cells) {
  const minX = Math.min(...cells.map(([x]) => x));
  const minY = Math.min(...cells.map(([, y]) => y));
  return cells
    .map(([x, y]) => ({ x: x - minX, y: y - minY }))
    .sort((a, b) => a.y - b.y || a.x - b.x);
}

function rotateOnceInFourByFour(cells) {
  return cells.map(([x, y]) => [3 - y, x]);
}

function buildRotations(type) {
  const rotations = [];
  let cells = BASE_CELLS[type].map(([x, y]) => [x, y]);
  for (let rotation = 0; rotation < 4; rotation += 1) {
    rotations.push(normalizeCells(cells));
    cells = rotateOnceInFourByFour(cells);
  }
  if (type === "O") {
    return Array.from({ length: 4 }, () => rotations[0].map((cell) => ({ ...cell })));
  }
  return rotations;
}

export const TETROMINOES = Object.fromEntries(
  PIECE_TYPES.map((type) => [
    type,
    {
      type,
      color: PIECE_COLORS[type],
      light: PIECE_LIGHTS[type],
      rotations: buildRotations(type),
    },
  ]),
);

export function createEmptyBoard(width = BOARD_WIDTH, height = BOARD_HEIGHT) {
  return Array.from({ length: height }, () => Array.from({ length: width }, () => null));
}

export function cloneBoard(board) {
  return board.map((row) => row.slice());
}

export function pieceCells(piece) {
  if (!piece || !TETROMINOES[piece.type]) return [];
  const rotation = ((piece.rotation % 4) + 4) % 4;
  return TETROMINOES[piece.type].rotations[rotation];
}

export function pieceBounds(cells) {
  if (!cells.length) return { width: 0, height: 0 };
  return {
    width: Math.max(...cells.map((cell) => cell.x)) + 1,
    height: Math.max(...cells.map((cell) => cell.y)) + 1,
  };
}

export function isCollision(board, piece, width = BOARD_WIDTH, height = BOARD_HEIGHT) {
  for (const cell of pieceCells(piece)) {
    const x = piece.x + cell.x;
    const y = piece.y + cell.y;
    if (x < 0 || x >= width || y >= height) return true;
    if (y >= 0 && board[y]?.[x]) return true;
  }
  return false;
}

export function mergePiece(board, piece) {
  for (const cell of pieceCells(piece)) {
    const x = piece.x + cell.x;
    const y = piece.y + cell.y;
    if (y >= 0 && y < board.length && x >= 0 && x < board[y].length) {
      board[y][x] = piece.type;
    }
  }
  return board;
}

export function clearCompletedLines(board) {
  const clearedRows = [];
  const width = board[0]?.length ?? BOARD_WIDTH;
  for (let y = board.length - 1; y >= 0; y -= 1) {
    if (board[y].every(Boolean)) {
      clearedRows.push(y);
      board.splice(y, 1);
      board.unshift(Array.from({ length: width }, () => null));
      y += 1;
    }
  }
  return { lines: clearedRows.length, rows: clearedRows.sort((a, b) => a - b) };
}

export function shuffledSevenBag(rng = Math.random) {
  const bag = PIECE_TYPES.slice();
  for (let i = bag.length - 1; i > 0; i -= 1) {
    const j = Math.floor(rng() * (i + 1));
    [bag[i], bag[j]] = [bag[j], bag[i]];
  }
  return bag;
}

export class RandomBag {
  constructor(rng = Math.random) {
    this.rng = rng;
    this.queue = [];
  }

  refill() {
    this.queue.push(...shuffledSevenBag(this.rng));
  }

  ensure(count = 1) {
    while (this.queue.length < count) this.refill();
  }

  next() {
    this.ensure(1);
    return this.queue.shift();
  }

  peek(count = NEXT_QUEUE_SIZE) {
    this.ensure(count);
    return this.queue.slice(0, count);
  }
}

export class GameCore {
  constructor(options = {}) {
    this.width = options.width ?? BOARD_WIDTH;
    this.height = options.height ?? BOARD_HEIGHT;
    this.rng = options.rng ?? Math.random;
    this.reset({ autoStart: options.autoStart !== false });
  }

  reset(options = {}) {
    const { autoStart = true } = options;
    this.board = createEmptyBoard(this.width, this.height);
    this.bag = new RandomBag(this.rng);
    this.active = null;
    this.holdType = null;
    this.holdLocked = false;
    this.score = 0;
    this.lines = 0;
    this.level = 0;
    this.dropCounter = 0;
    this.paused = false;
    this.gameOver = false;
    this.events = [{ type: "restart" }];
    if (autoStart) this.spawnPiece();
  }

  get displayLevel() {
    return this.level + 1;
  }

  getDropInterval() {
    return Math.max(80, 900 - this.level * 70);
  }

  spawnPiece(type = this.bag.next()) {
    if (!TETROMINOES[type]) throw new Error(`Unknown tetromino: ${type}`);
    const cells = TETROMINOES[type].rotations[0];
    const bounds = pieceBounds(cells);
    const piece = {
      type,
      rotation: 0,
      x: Math.floor((this.width - bounds.width) / 2),
      y: 0,
    };
    if (isCollision(this.board, piece, this.width, this.height)) {
      this.active = piece;
      this.gameOver = true;
      this.paused = false;
      this.events.push({ type: "gameOver", score: this.score });
      return false;
    }
    this.active = piece;
    this.dropCounter = 0;
    this.events.push({ type: "spawn", piece: type });
    return true;
  }

  canMove(dx, dy, piece = this.active) {
    if (!piece) return false;
    return !isCollision(
      this.board,
      { ...piece, x: piece.x + dx, y: piece.y + dy },
      this.width,
      this.height,
    );
  }

  move(dx, dy = 0) {
    if (!this.active || this.paused || this.gameOver) return false;
    if (!this.canMove(dx, dy)) return false;
    this.active.x += dx;
    this.active.y += dy;
    this.events.push({ type: "move", dx, dy });
    return true;
  }

  rotate(direction = 1) {
    if (!this.active || this.paused || this.gameOver) return false;
    const nextRotation = (this.active.rotation + direction + 4) % 4;
    for (const [kickX, kickY] of DEFAULT_KICKS) {
      const rotated = {
        ...this.active,
        rotation: nextRotation,
        x: this.active.x + kickX,
        y: this.active.y + kickY,
      };
      if (!isCollision(this.board, rotated, this.width, this.height)) {
        this.active = rotated;
        this.events.push({ type: "rotate", direction, kickX, kickY });
        return true;
      }
    }
    this.events.push({ type: "blockedRotate", direction });
    return false;
  }

  softDrop() {
    if (!this.active || this.paused || this.gameOver) return false;
    if (this.move(0, 1)) {
      this.score += 1;
      this.dropCounter = 0;
      this.events.push({ type: "softDrop" });
      return true;
    }
    this.lockPiece();
    return false;
  }

  hardDrop() {
    if (!this.active || this.paused || this.gameOver) return 0;
    let distance = 0;
    while (this.canMove(0, 1)) {
      this.active.y += 1;
      distance += 1;
    }
    this.score += distance * 2;
    this.events.push({ type: "hardDrop", distance });
    this.lockPiece();
    return distance;
  }

  holdPiece() {
    if (!this.active || this.paused || this.gameOver || this.holdLocked) return false;
    const currentType = this.active.type;
    const swapType = this.holdType;
    this.holdType = currentType;
    this.holdLocked = true;
    if (swapType) {
      this.spawnPiece(swapType);
    } else {
      this.spawnPiece(this.bag.next());
    }
    this.events.push({ type: "hold", holdType: this.holdType, activeType: this.active?.type });
    return !this.gameOver;
  }

  gravityStep() {
    if (!this.active || this.paused || this.gameOver) return false;
    if (this.canMove(0, 1)) {
      this.active.y += 1;
      this.events.push({ type: "gravity" });
      return true;
    }
    this.lockPiece();
    return false;
  }

  tick(deltaMs) {
    if (!this.active || this.paused || this.gameOver) return;
    this.dropCounter += deltaMs;
    const interval = this.getDropInterval();
    while (this.dropCounter >= interval && this.active && !this.gameOver) {
      this.dropCounter -= interval;
      if (!this.gravityStep()) break;
    }
  }

  lockPiece() {
    if (!this.active || this.gameOver) return { lines: 0, rows: [] };
    const lockedPiece = { ...this.active };
    const hasCellsAboveBoard = pieceCells(lockedPiece).some((cell) => lockedPiece.y + cell.y < 0);
    if (hasCellsAboveBoard) {
      this.gameOver = true;
      this.events.push({ type: "gameOver", score: this.score });
      return { lines: 0, rows: [] };
    }

    mergePiece(this.board, lockedPiece);
    const clearResult = clearCompletedLines(this.board);
    if (clearResult.lines > 0) {
      const levelBeforeClear = this.level;
      this.score += (LINE_CLEAR_SCORES[clearResult.lines] ?? clearResult.lines * 200) * (levelBeforeClear + 1);
      this.lines += clearResult.lines;
      this.level = Math.floor(this.lines / LINES_PER_LEVEL);
      this.events.push({ type: "lineClear", ...clearResult, score: this.score, level: this.level });
    }

    this.events.push({ type: "lock", piece: lockedPiece.type, x: lockedPiece.x, y: lockedPiece.y });
    this.active = null;
    this.holdLocked = false;
    this.spawnPiece();
    return clearResult;
  }

  togglePause(force) {
    if (this.gameOver) return this.paused;
    this.paused = typeof force === "boolean" ? force : !this.paused;
    this.events.push({ type: this.paused ? "pause" : "resume" });
    return this.paused;
  }

  getGhostPiece() {
    if (!this.active) return null;
    const ghost = { ...this.active };
    while (!isCollision(this.board, { ...ghost, y: ghost.y + 1 }, this.width, this.height)) {
      ghost.y += 1;
    }
    return ghost;
  }

  getNextQueue(count = NEXT_QUEUE_SIZE) {
    return this.bag.peek(count);
  }

  consumeEvents() {
    const events = this.events.slice();
    this.events.length = 0;
    return events;
  }
}

const browserGlobalsAvailable = typeof window !== "undefined" && typeof document !== "undefined";

if (browserGlobalsAvailable) {
  const HIGH_SCORE_KEY = "polished-tetris-high-score-v1";

  class TetrisUI {
    constructor() {
      this.core = new GameCore();
      this.boardCanvas = document.querySelector("#board");
      this.holdCanvas = document.querySelector("#holdCanvas");
      this.nextCanvas = document.querySelector("#nextCanvas");
      this.scoreEl = document.querySelector("#scoreValue");
      this.linesEl = document.querySelector("#linesValue");
      this.levelEl = document.querySelector("#levelValue");
      this.highScoreEl = document.querySelector("#highScoreValue");
      this.statusEl = document.querySelector("#statusValue");
      this.overlay = document.querySelector("#stateOverlay");
      this.overlayTitle = document.querySelector("#overlayTitle");
      this.overlayMessage = document.querySelector("#overlayMessage");
      this.pauseButtons = Array.from(document.querySelectorAll('[data-action="pause"]'));
      this.toast = document.querySelector("#toast");
      this.highScore = this.loadHighScore();
      this.lastTime = 0;
      this.toastTimer = null;
      this.setupInput();
      this.resizeCanvases();
      window.addEventListener("resize", () => this.resizeCanvases());
      requestAnimationFrame((time) => this.frame(time));
    }

    loadHighScore() {
      const raw = window.localStorage.getItem(HIGH_SCORE_KEY);
      const parsed = Number.parseInt(raw ?? "0", 10);
      return Number.isFinite(parsed) ? parsed : 0;
    }

    saveHighScore() {
      window.localStorage.setItem(HIGH_SCORE_KEY, String(this.highScore));
    }

    resizeCanvases() {
      for (const canvas of [this.boardCanvas, this.holdCanvas, this.nextCanvas]) {
        const rect = canvas.getBoundingClientRect();
        const dpr = window.devicePixelRatio || 1;
        const width = Math.max(1, Math.round(rect.width * dpr));
        const height = Math.max(1, Math.round(rect.height * dpr));
        if (canvas.width !== width || canvas.height !== height) {
          canvas.width = width;
          canvas.height = height;
        }
      }
      this.draw();
    }

    frame(time) {
      const delta = this.lastTime ? Math.min(80, time - this.lastTime) : 0;
      this.lastTime = time;
      this.core.tick(delta);
      this.processEvents(this.core.consumeEvents());
      this.updateHighScore();
      this.updatePanels();
      this.draw();
      requestAnimationFrame((nextTime) => this.frame(nextTime));
    }

    updateHighScore() {
      if (this.core.score > this.highScore) {
        this.highScore = this.core.score;
        this.saveHighScore();
      }
    }

    processEvents(events) {
      for (const event of events) {
        if (event.type === "lineClear") {
          const label = event.lines === 4 ? "TETRIS!" : `${event.lines} line${event.lines > 1 ? "s" : ""} cleared`;
          this.showToast(label);
          this.boardCanvas.classList.add("flash");
          window.setTimeout(() => this.boardCanvas.classList.remove("flash"), 220);
        }
        if (event.type === "hardDrop") {
          this.boardCanvas.classList.add("thump");
          window.setTimeout(() => this.boardCanvas.classList.remove("thump"), 120);
        }
        if (event.type === "gameOver") this.showToast("Game over");
      }
    }

    showToast(message) {
      if (!this.toast) return;
      this.toast.textContent = message;
      this.toast.classList.add("show");
      window.clearTimeout(this.toastTimer);
      this.toastTimer = window.setTimeout(() => this.toast.classList.remove("show"), 1200);
    }

    updatePanels() {
      this.scoreEl.textContent = this.core.score.toLocaleString();
      this.linesEl.textContent = this.core.lines.toLocaleString();
      this.levelEl.textContent = this.core.displayLevel.toLocaleString();
      this.highScoreEl.textContent = this.highScore.toLocaleString();
      const status = this.core.gameOver ? "Game Over" : this.core.paused ? "Paused" : "Playing";
      this.statusEl.textContent = status;
      for (const pauseButton of this.pauseButtons) pauseButton.textContent = this.core.paused ? "Resume" : "Pause";
      this.updateOverlay();
    }

    updateOverlay() {
      if (!this.overlay) return;
      if (this.core.gameOver) {
        this.overlay.hidden = false;
        this.overlayTitle.textContent = "Game Over";
        this.overlayMessage.textContent = `Score ${this.core.score.toLocaleString()} · Press R or Restart`;
      } else if (this.core.paused) {
        this.overlay.hidden = false;
        this.overlayTitle.textContent = "Paused";
        this.overlayMessage.textContent = "Press P, Esc, or Pause to resume";
      } else {
        this.overlay.hidden = true;
      }
    }

    setupInput() {
      const repeatable = new Set(["left", "right", "softDrop"]);
      const actionForCode = {
        ArrowLeft: "left",
        KeyA: "left",
        ArrowRight: "right",
        KeyD: "right",
        ArrowDown: "softDrop",
        KeyS: "softDrop",
        ArrowUp: "rotateCW",
        KeyX: "rotateCW",
        KeyZ: "rotateCCW",
        ControlLeft: "rotateCCW",
        ControlRight: "rotateCCW",
        Space: "hardDrop",
        ShiftLeft: "hold",
        ShiftRight: "hold",
        KeyC: "hold",
        KeyP: "pause",
        Escape: "pause",
        KeyR: "restart",
      };

      window.addEventListener("keydown", (event) => {
        const action = actionForCode[event.code];
        if (!action) return;
        event.preventDefault();
        if (event.repeat && !repeatable.has(action)) return;
        this.performAction(action);
      });

      document.querySelectorAll("[data-action]").forEach((button) => {
        const action = button.dataset.action;
        let interval = null;
        let delay = null;
        const stopRepeat = () => {
          window.clearInterval(interval);
          window.clearTimeout(delay);
          interval = null;
          delay = null;
          button.classList.remove("is-pressed");
        };
        button.addEventListener("pointerdown", (event) => {
          event.preventDefault();
          button.setPointerCapture?.(event.pointerId);
          button.classList.add("is-pressed");
          this.performAction(action);
          if (repeatable.has(action)) {
            delay = window.setTimeout(() => {
              interval = window.setInterval(() => this.performAction(action), action === "softDrop" ? 55 : 85);
            }, 180);
          }
        });
        for (const eventName of ["pointerup", "pointerleave", "pointercancel", "lostpointercapture"]) {
          button.addEventListener(eventName, stopRepeat);
        }
        button.addEventListener("contextmenu", (event) => event.preventDefault());
      });

      document.addEventListener(
        "touchmove",
        (event) => {
          if (event.target.closest(".touch-controls") || event.target.closest(".board-panel")) {
            event.preventDefault();
          }
        },
        { passive: false },
      );
    }

    performAction(action) {
      switch (action) {
        case "left":
          this.core.move(-1, 0);
          break;
        case "right":
          this.core.move(1, 0);
          break;
        case "softDrop":
          this.core.softDrop();
          break;
        case "rotateCW":
          this.core.rotate(1);
          break;
        case "rotateCCW":
          this.core.rotate(-1);
          break;
        case "hardDrop":
          this.core.hardDrop();
          break;
        case "hold":
          this.core.holdPiece();
          break;
        case "pause":
          this.core.togglePause();
          break;
        case "restart":
          this.core.reset();
          this.showToast("Restarted");
          break;
        default:
          break;
      }
      this.processEvents(this.core.consumeEvents());
      this.updateHighScore();
      this.updatePanels();
      this.draw();
    }

    draw() {
      this.drawBoard();
      this.drawHold();
      this.drawNextQueue();
    }

    drawBoard() {
      const canvas = this.boardCanvas;
      const ctx = canvas.getContext("2d");
      const width = canvas.width;
      const height = canvas.height;
      ctx.clearRect(0, 0, width, height);
      const bg = ctx.createLinearGradient(0, 0, width, height);
      bg.addColorStop(0, "#101a33");
      bg.addColorStop(0.55, "#071022");
      bg.addColorStop(1, "#0e1730");
      roundedRect(ctx, 0, 0, width, height, Math.max(16, width * 0.04));
      ctx.fillStyle = bg;
      ctx.fill();

      const cell = Math.floor(Math.min(width / BOARD_WIDTH, height / BOARD_HEIGHT));
      const offsetX = Math.floor((width - cell * BOARD_WIDTH) / 2);
      const offsetY = Math.floor((height - cell * BOARD_HEIGHT) / 2);

      this.drawGrid(ctx, cell, offsetX, offsetY);

      for (let y = 0; y < this.core.height; y += 1) {
        for (let x = 0; x < this.core.width; x += 1) {
          const type = this.core.board[y][x];
          if (type) drawBlock(ctx, x, y, type, cell, offsetX, offsetY, 1, false);
        }
      }

      const ghost = this.core.getGhostPiece();
      if (ghost && this.core.active && ghost.y !== this.core.active.y) {
        for (const cellPos of pieceCells(ghost)) {
          drawGhostBlock(ctx, ghost.x + cellPos.x, ghost.y + cellPos.y, ghost.type, cell, offsetX, offsetY);
        }
      }

      if (this.core.active) {
        for (const cellPos of pieceCells(this.core.active)) {
          drawBlock(
            ctx,
            this.core.active.x + cellPos.x,
            this.core.active.y + cellPos.y,
            this.core.active.type,
            cell,
            offsetX,
            offsetY,
            1,
            true,
          );
        }
      }

      ctx.save();
      ctx.strokeStyle = "rgba(151, 202, 255, 0.36)";
      ctx.lineWidth = Math.max(2, cell * 0.06);
      roundedRect(ctx, offsetX + 1, offsetY + 1, cell * BOARD_WIDTH - 2, cell * BOARD_HEIGHT - 2, cell * 0.35);
      ctx.stroke();
      ctx.restore();
    }

    drawGrid(ctx, cell, offsetX, offsetY) {
      ctx.save();
      ctx.strokeStyle = "rgba(255,255,255,0.045)";
      ctx.lineWidth = Math.max(1, cell * 0.025);
      for (let x = 0; x <= BOARD_WIDTH; x += 1) {
        const px = offsetX + x * cell;
        ctx.beginPath();
        ctx.moveTo(px, offsetY);
        ctx.lineTo(px, offsetY + BOARD_HEIGHT * cell);
        ctx.stroke();
      }
      for (let y = 0; y <= BOARD_HEIGHT; y += 1) {
        const py = offsetY + y * cell;
        ctx.beginPath();
        ctx.moveTo(offsetX, py);
        ctx.lineTo(offsetX + BOARD_WIDTH * cell, py);
        ctx.stroke();
      }
      ctx.restore();
    }

    drawHold() {
      drawMiniPiece(this.holdCanvas, this.core.holdType, "HOLD");
    }

    drawNextQueue() {
      const canvas = this.nextCanvas;
      const ctx = canvas.getContext("2d");
      const width = canvas.width;
      const height = canvas.height;
      ctx.clearRect(0, 0, width, height);
      drawPanelBackground(ctx, width, height);
      const queue = this.core.getNextQueue(NEXT_QUEUE_SIZE);
      const slotHeight = height / NEXT_QUEUE_SIZE;
      queue.forEach((type, index) => {
        const top = index * slotHeight;
        if (index > 0) {
          ctx.strokeStyle = "rgba(255,255,255,0.08)";
          ctx.beginPath();
          ctx.moveTo(width * 0.12, top);
          ctx.lineTo(width * 0.88, top);
          ctx.stroke();
        }
        drawPieceInBox(ctx, type, 0, top, width, slotHeight, index === 0 ? 1 : 0.82);
      });
    }
  }

  function drawMiniPiece(canvas, type, label) {
    const ctx = canvas.getContext("2d");
    const width = canvas.width;
    const height = canvas.height;
    ctx.clearRect(0, 0, width, height);
    drawPanelBackground(ctx, width, height);
    ctx.save();
    ctx.fillStyle = "rgba(226,240,255,0.55)";
    ctx.font = `${Math.max(10, width * 0.09)}px Inter, system-ui, sans-serif`;
    ctx.letterSpacing = "0.08em";
    ctx.fillText(label, width * 0.1, height * 0.18);
    ctx.restore();
    if (type) {
      drawPieceInBox(ctx, type, 0, height * 0.14, width, height * 0.82, 1);
    } else {
      ctx.save();
      ctx.fillStyle = "rgba(255,255,255,0.25)";
      ctx.font = `${Math.max(18, width * 0.18)}px Inter, system-ui, sans-serif`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText("—", width / 2, height * 0.58);
      ctx.restore();
    }
  }

  function drawPanelBackground(ctx, width, height) {
    const bg = ctx.createLinearGradient(0, 0, width, height);
    bg.addColorStop(0, "rgba(29,45,86,0.92)");
    bg.addColorStop(1, "rgba(9,17,38,0.92)");
    roundedRect(ctx, 0, 0, width, height, Math.max(10, width * 0.08));
    ctx.fillStyle = bg;
    ctx.fill();
    ctx.strokeStyle = "rgba(170,210,255,0.16)";
    ctx.lineWidth = Math.max(1, width * 0.01);
    ctx.stroke();
  }

  function drawPieceInBox(ctx, type, boxX, boxY, boxWidth, boxHeight, alpha = 1) {
    const cells = TETROMINOES[type].rotations[0];
    const bounds = pieceBounds(cells);
    const cell = Math.floor(Math.min(boxWidth / 5, boxHeight / 4.5));
    const offsetX = boxX + (boxWidth - bounds.width * cell) / 2;
    const offsetY = boxY + (boxHeight - bounds.height * cell) / 2;
    for (const pos of cells) {
      drawBlock(ctx, pos.x, pos.y, type, cell, offsetX, offsetY, alpha, false);
    }
  }

  function drawBlock(ctx, gridX, gridY, type, cell, offsetX, offsetY, alpha = 1, active = false) {
    if (gridY < 0) return;
    const x = offsetX + gridX * cell;
    const y = offsetY + gridY * cell;
    const pad = Math.max(1, cell * 0.08);
    const size = cell - pad * 2;
    const radius = Math.max(3, cell * 0.18);
    const color = PIECE_COLORS[type] ?? "#ffffff";
    const light = PIECE_LIGHTS[type] ?? "#ffffff";
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.shadowColor = color;
    ctx.shadowBlur = active ? cell * 0.34 : cell * 0.18;
    const gradient = ctx.createLinearGradient(x, y, x + size, y + size);
    gradient.addColorStop(0, light);
    gradient.addColorStop(0.45, color);
    gradient.addColorStop(1, "#152039");
    roundedRect(ctx, x + pad, y + pad, size, size, radius);
    ctx.fillStyle = gradient;
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.strokeStyle = "rgba(255,255,255,0.38)";
    ctx.lineWidth = Math.max(1, cell * 0.035);
    ctx.stroke();
    ctx.fillStyle = "rgba(255,255,255,0.16)";
    roundedRect(ctx, x + pad * 1.8, y + pad * 1.7, size * 0.62, size * 0.24, radius * 0.6);
    ctx.fill();
    ctx.restore();
  }

  function drawGhostBlock(ctx, gridX, gridY, type, cell, offsetX, offsetY) {
    if (gridY < 0) return;
    const x = offsetX + gridX * cell;
    const y = offsetY + gridY * cell;
    const pad = Math.max(2, cell * 0.13);
    ctx.save();
    ctx.strokeStyle = PIECE_COLORS[type] ?? "#ffffff";
    ctx.globalAlpha = 0.54;
    ctx.lineWidth = Math.max(2, cell * 0.07);
    ctx.setLineDash([cell * 0.18, cell * 0.12]);
    roundedRect(ctx, x + pad, y + pad, cell - pad * 2, cell - pad * 2, cell * 0.14);
    ctx.stroke();
    ctx.restore();
  }

  function roundedRect(ctx, x, y, width, height, radius) {
    const r = Math.min(radius, width / 2, height / 2);
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + width, y, x + width, y + height, r);
    ctx.arcTo(x + width, y + height, x, y + height, r);
    ctx.arcTo(x, y + height, x, y, r);
    ctx.arcTo(x, y, x + width, y, r);
    ctx.closePath();
  }

  window.addEventListener("DOMContentLoaded", () => new TetrisUI());
}
