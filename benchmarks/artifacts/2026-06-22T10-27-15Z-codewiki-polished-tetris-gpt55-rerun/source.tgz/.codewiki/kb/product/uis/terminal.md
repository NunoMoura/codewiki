# Terminal UI

Terminal and CLI surfaces expose disposable views over KB and trace truth.
