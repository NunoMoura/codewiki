# Agents

Agents use CodeWiki traces and KB refs to resume work without treating chat history as source truth.
