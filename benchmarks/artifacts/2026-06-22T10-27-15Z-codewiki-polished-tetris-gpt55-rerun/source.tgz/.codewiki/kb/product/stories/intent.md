# Intent

CodeWiki preserves accepted intent as decisions, planned work, implementation evidence, and source-backed references.
