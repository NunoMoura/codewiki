# Navigation

CodeWiki starts from compact state views and expands to exact KB, trace, source, test, and Git refs only when needed.
