# Lexicon

codewiki-benchmark-polished-tetris uses CodeWiki terms exactly. Semantic loops are decision, planning, and implementation. Runtime is an outer coordination loop. Trace JSONL is append-only workflow truth. Views are disposable projections.
