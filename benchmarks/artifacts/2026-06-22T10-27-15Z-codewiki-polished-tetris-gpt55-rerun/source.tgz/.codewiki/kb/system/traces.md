# Traces

Trace files live at `.codewiki/traces/TRACE-*.jsonl`. Records are append-only. Semantic events include `loop` plus a specific event such as `rows_approved`, `work_units_created`, or `evidence_accepted`. Runtime events coordinate claims and omit `loop`; they are not semantic loop truth.
