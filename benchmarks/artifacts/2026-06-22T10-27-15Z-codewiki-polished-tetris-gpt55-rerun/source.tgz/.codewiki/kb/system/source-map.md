# Source Map

`source-map.yaml` maps source, tests, generated views, trace events, and owning KB docs. It is the machine-readable ownership contract used by loop exit conditions and project checks.
