# Runtime

Runtime schedules and claims executable work from disposable views. Runtime is an outer coordination loop, not a fourth semantic loop. Runtime policy comes from config and durable work state comes from traces.
