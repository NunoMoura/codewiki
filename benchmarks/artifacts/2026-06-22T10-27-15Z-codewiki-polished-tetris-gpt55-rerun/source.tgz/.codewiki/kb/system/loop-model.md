# Loop Model

CodeWiki has exactly three semantic loops: decision, planning, and implementation. Runtime coordinates work outside those loops. Each semantic loop emits durable facts with `loop` naming the semantic authority and `event` naming what changed, plus output, progress, and exit status.
