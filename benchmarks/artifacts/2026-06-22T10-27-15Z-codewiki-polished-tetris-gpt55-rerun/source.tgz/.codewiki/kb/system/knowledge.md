# Knowledge

Knowledge lives in `.codewiki/kb/**`. Product docs explain user-facing intent. System docs explain architecture and loop behavior. Markdown files must start with body content, not frontmatter.
