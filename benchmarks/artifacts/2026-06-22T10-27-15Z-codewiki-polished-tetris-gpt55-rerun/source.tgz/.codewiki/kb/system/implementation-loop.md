# Implementation Loop

Implementation iterations record source changes, tests, evidence, worker claims, and coverage of planned work refs.

Exit conditions belong to this loop. They may use deterministic helper predicates, but verdict and routing stay loop-owned. Valid exit statuses are `continue`, `exit`, `route_back`, and `blocked`.
