# API

CodeWiki host adapters should call core facades for state, config, decisions, planning, implementation, runtime work-unit claims, and archive lifecycle. Adapters must not introduce alternate workflow truth.
