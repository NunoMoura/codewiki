# System Overview

codewiki-benchmark-polished-tetris CodeWiki state has three durable roots: KB knowledge, trace JSONL workflow records, and disposable views.

## Detected boundaries

- No source boundaries detected yet.
