# Decision Loop

Decision iterations capture accepted intent, alternatives, risks, and knowledge impact before planning starts.

Exit conditions belong to this loop. They may use deterministic helper predicates, but verdict and routing stay loop-owned. Valid exit statuses are `continue`, `exit`, `route_back`, and `blocked`.
