# Polished Tetris

A dependency-free browser Tetris game built for the benchmark. It includes all seven tetrominoes, a seven-bag randomizer, hold, five-piece next queue, ghost piece, scoring, levels, pause/resume, restart, game-over display, responsive keyboard/touch controls, and local high-score persistence.

## Run locally

```bash
npm start
```

Open <http://localhost:4173> in a browser. You can also set a custom port:

```bash
PORT=3000 npm start
```

## Controls

- Move: `←`/`→` or `A`/`D`
- Rotate clockwise: `↑` or `X`
- Rotate counter-clockwise: `Z` or `Ctrl`
- Soft drop: `↓` or `S`
- Hard drop: `Space`
- Hold: `C` or `Shift`
- Pause/resume: `P` or `Esc`
- Restart: `R`

Touch controls are shown on screen and use pointer events with scroll prevention for phone-sized screens.

## Checks

```bash
npm test
```

The scripted sanity check validates seven-bag fairness, all tetromino spawn/rotation/collision behavior, locking and line-clear scoring, hold rules, and level progression.
