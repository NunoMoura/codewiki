import assert from "node:assert/strict";
import {
  BOARD_HEIGHT,
  BOARD_WIDTH,
  GameCore,
  PIECE_TYPES,
  RandomBag,
  TETROMINOES,
  createEmptyBoard,
  isCollision,
  pieceCells,
} from "../src/game.js";

function testSevenBagFairness() {
  const bag = new RandomBag(() => 0.37);
  const drawn = Array.from({ length: 28 }, () => bag.next());
  for (let start = 0; start < drawn.length; start += PIECE_TYPES.length) {
    const chunk = drawn.slice(start, start + PIECE_TYPES.length);
    assert.deepEqual([...chunk].sort(), [...PIECE_TYPES].sort(), `bag ${start / 7 + 1} should contain all seven pieces once`);
  }
  assert.equal(new Set(bag.peek(7)).size, 7, "peeked queue should expose a complete fair bag when aligned");
}

function testAllPiecesSpawnRotateAndCollide() {
  for (const type of PIECE_TYPES) {
    assert.equal(TETROMINOES[type].rotations.length, 4, `${type} has four rotation states`);
    for (const rotation of TETROMINOES[type].rotations) {
      assert.equal(rotation.length, 4, `${type} rotation has four cells`);
    }

    const core = new GameCore({ autoStart: false, rng: () => 0.1 });
    assert.equal(core.spawnPiece(type), true, `${type} spawns`);
    assert.equal(isCollision(core.board, core.active, BOARD_WIDTH, BOARD_HEIGHT), false, `${type} spawn does not collide`);
    assert.equal(core.rotate(1), true, `${type} rotates clockwise`);
    assert.equal(core.rotate(-1), true, `${type} rotates counter-clockwise`);
  }

  const wallCore = new GameCore({ autoStart: false, rng: () => 0.2 });
  wallCore.spawnPiece("O");
  while (wallCore.move(-1, 0));
  assert.equal(wallCore.active.x, 0, "O piece stops at left wall");
  assert.equal(wallCore.move(-1, 0), false, "moving through the left wall is rejected");
  assert.equal(isCollision(wallCore.board, { ...wallCore.active, x: -1 }, BOARD_WIDTH, BOARD_HEIGHT), true, "left wall collision is detected");
}

function testLockingAndLineClearScoring() {
  const core = new GameCore({ autoStart: false, rng: () => 0.45 });
  core.board = createEmptyBoard();
  for (let x = 0; x < BOARD_WIDTH; x += 1) {
    if (x !== 4) core.board[BOARD_HEIGHT - 1][x] = "Z";
  }

  core.spawnPiece("I");
  core.active.rotation = 1;
  core.active.x = 4;
  core.active.y = 0;
  const beforeCells = pieceCells(core.active).map((cell) => [core.active.x + cell.x, core.active.y + cell.y]);
  assert.equal(beforeCells.length, 4, "active I piece has four lockable cells");

  const distance = core.hardDrop();
  assert.ok(distance > 0, "hard drop moves the piece to the stack");
  assert.equal(core.lines, 1, "locking the I piece clears the prepared line");
  assert.ok(core.score >= 100, "line clear and hard drop increase score");
  assert.equal(core.level, 0, "level remains zero-indexed until ten lines are cleared");
  assert.ok(core.active, "a new piece spawns after lock");
}

function testHoldRulesAndLevelProgression() {
  const core = new GameCore({ autoStart: false, rng: () => 0.65 });
  core.spawnPiece("T");
  assert.equal(core.holdPiece(), true, "first hold succeeds");
  assert.equal(core.holdType, "T", "held type is stored");
  assert.equal(core.holdLocked, true, "hold is locked until the piece locks");
  assert.equal(core.holdPiece(), false, "second hold before lock is rejected");

  core.hardDrop();
  assert.equal(core.holdLocked, false, "hold unlocks after the active piece locks");
  assert.equal(core.holdPiece(), true, "hold can be used again on the next piece");

  const levelCore = new GameCore({ autoStart: false, rng: () => 0.25 });
  levelCore.lines = 9;
  levelCore.level = 0;
  levelCore.board = createEmptyBoard();
  for (let x = 0; x < BOARD_WIDTH; x += 1) {
    if (x !== 4) levelCore.board[BOARD_HEIGHT - 1][x] = "J";
  }
  levelCore.spawnPiece("I");
  levelCore.active.rotation = 1;
  levelCore.active.x = 4;
  levelCore.hardDrop();
  assert.equal(levelCore.lines, 10, "line total reaches the next threshold");
  assert.equal(levelCore.level, 1, "level advances every ten cleared lines");
  assert.equal(levelCore.displayLevel, 2, "display level is human-friendly and starts at one");
}

function run() {
  testSevenBagFairness();
  testAllPiecesSpawnRotateAndCollide();
  testLockingAndLineClearScoring();
  testHoldRulesAndLevelProgression();
  console.log("Tetris logic sanity checks passed");
}

run();
